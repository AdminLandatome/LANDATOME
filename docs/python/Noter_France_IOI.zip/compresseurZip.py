import os
import shutil

filename = "compressed"
format = "zip"
directory = os.getcwd()
shutil.make_archive(filename, format, directory)
