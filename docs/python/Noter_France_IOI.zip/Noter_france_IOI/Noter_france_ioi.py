import os
def lire_dossier():
    lenoyau = os.getcwd()
    rep = os.listdir(lenoyau)
    noyau1 = rep[0]
    return noyau1 


NomDeFichier = "France-IOI – Groupe tazieff_1ST2S_2022.htm"

def extraction(nom_de_fichier):
    with open(nom_de_fichier,'r',encoding='utf-8') as fichier :
        result = fichier.readlines()
    return result

page = extraction(lire_dossier())
   
#Pour trouver les progressions
numero_ligne = 0
for une_ligne in page:
    numero_ligne += 1
    if "Progression" in une_ligne:
        bonne_ligne = numero_ligne -1
bonne_ligne += 5

#Ligne de la page surlaquelle on va travailler
le_texte = page[bonne_ligne]

#Creation de la liste des élèves

def creer_liste_eleves(document):
    tempo = []
    retour =[]
    a = 0
    for ligne in document:
        a += 1
        if "Membres du groupe" in ligne:
            cible = a+2
    tempo.append(document[cible])
    while not("</ul>" in document[cible+1]):
        cible += 2
        tempo.append(document[cible])
        
    for ligne in tempo:
        if not('Administrateur' in ligne):
            fin = ligne.find('@')-6
            retour.append(ligne[6:fin].upper())
        else:
            retour.append('Administrateur')
    return retour

liste_eleves = creer_liste_eleves(page)[:]

#On recrée le tableau à partir de ligne de la page web enregistrée

coupe_tr = le_texte.split("<tr")
coupe_td = []
for ligne in coupe_tr :
    
    coupe_td.append(ligne.split("<td"))

resultat = coupe_td[:]

#On remplace le contenu des cellules 
for ligne in range(len(coupe_td)):
    
    for colonne in range(len(coupe_td[ligne])):
        
        if 'lightgreen' in coupe_td[ligne][colonne]:
            resultat[ligne][colonne] = 'vert'
        elif 'lightgrey' in coupe_td[ligne][colonne]:
            resultat[ligne][colonne] = 'gris'
        elif '#FF8080' in coupe_td[ligne][colonne]:
            resultat[ligne][colonne] = 'rouge'
        elif 'Non commencé' in coupe_td[ligne][colonne]:
            resultat[ligne][colonne] = 'Non commencé'    
        else :
            resultat[ligne][colonne] = 'AUTRE'


#On enleve les lignes inutiles pour nous
resultat_epure = []
for ligne in resultat:
    if len(ligne) > 2:
        resultat_epure.append(ligne[2:])


resultat_epure = resultat_epure[1:]


# On cree la liste de notes de chaque élèves
les_notes =  []
denominateur = int(input("des notes sur combien ? : "))   # On choisit le denominateur des notes
for numero_eleve in range(len(liste_eleves)):
    notes = []
    note = 0
    nb_questions = 0
    for ligne in resultat_epure:
        if ligne[numero_eleve] == 'AUTRE':
            notes.append(str((round(note/nb_questions*denominateur,2)))+'/'+str(denominateur))
            note = 0
            nb_questions = -1
        elif ligne[numero_eleve] == 'vert':
            note += 1
        nb_questions += 1
    les_notes.append(notes)
"""    
les_resultats = {}
for numero in range(len(liste_eleves)):
    les_resultats[liste_eleves[numero]] = les_notes[numero]
"""
les_resultats_bis = []
for numero in range(len(liste_eleves)):
    les_resultats_bis.append((liste_eleves[numero],les_notes[numero]))

les_resultats_bis.sort()

with open('VOS_NOTES.txt', 'w', encoding = 'utf-8') as fichier_final:
    fichier_final.write('{:<30}'.format('Noms et Prénoms'))
    fichier_final.write('| ')
    for numero in range(len(les_resultats_bis[0][1])):
        mot = 'Série n° '+str(numero+1)
        fichier_final.write('{:<11}'.format(mot)+' | ')
    fichier_final.write('\n')
    for ligne in les_resultats_bis:
        if not ('Administrateur' in ligne[0]):
            fichier_final.write('{:<30}'.format(ligne[0]))
            fichier_final.write('| ')
            for note in ligne[1]:
                fichier_final.write('{:<11}'.format(note)+' | ')
            fichier_final.write('\n')
            fichier_final.write(f'{0:_>255}')
            fichier_final.write('\n')
    

with open('Vos_notes_pour_excel.csv','w',encoding='utf-8') as fichier_csv :
    fichier_csv.write('Noms et Prénoms'+';')
    mot = 'Série n°1 '
    for numero in range(1,len(les_resultats_bis[0][1])):
        mot += ';Série n° '+str(numero+1)
    fichier_csv.write(mot+'\n')
    for ligne in les_resultats_bis:
        if not ('Administrateur' in ligne[0]):
            serie_notes = ligne[0]
            for note in ligne[1]:
                serie_notes += ';'+note
            fichier_csv.write(serie_notes+'\n')
                    
