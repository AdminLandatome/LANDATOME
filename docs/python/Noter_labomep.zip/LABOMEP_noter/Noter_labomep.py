import os

def extraction(nom_fichier):
    tableau = []
    with open(nom_fichier,'r',encoding="utf-8") as fichier:
        for ele in fichier:
            tableau.append(ele[:-1].split(";"))
    return tableau

def nb_exo(tableau):
    return len(tableau[0])-1

# Les constantes
tableau = extraction('export_table_utf8.csv')
nb_exos = nb_exo(tableau)

def bareme():
    if input('définir le bareme vous-même ? (o/n) ') != 'o':
        return [20/nb_exos]*nb_exos
    reste = 20.0
    bareme = []
    for numero in range(nb_exos-1):
        print('il reste ', reste,' points pour ',nb_exos-numero,' exercice(s)')
        print("Entrez le nombre de points pour l'exercice n°",numero+1)
        test = (float(input()))
        while reste-test < 0:
            print('Ce nombre est trop élevé, entrez en un autre:')
            test = (float(input()))
            
        bareme.append(test)
        reste -= test
    print('il reste ',reste,' points pour le dernier exercice')
    bareme.append(reste)
    return bareme

#Creation du bareme
bareme = bareme()


def transforme(ligne):
    retour = ligne[:]
    for numero in range(1,len(ligne)):
        if ligne[numero] == '"Aucun résultat"' or ligne[numero] == '"Pas de score"':
            retour[numero] = 0
        else:
            retour[numero] = float((ligne[numero][1:-3]))/100
    return retour

    
def tableau_note(tableau):
    tableau_note = []
    for num_ligne in range(1,len(tableau)):
        ligne = transforme(tableau[num_ligne])
        note = 0
        for numero in range(1,len(ligne)):
            ligne[numero] = ligne[numero]*bareme[numero-1]
            
            note += ligne[numero]
            
        ligne.append(note)
        tableau_note.append(ligne)
    return tableau_note

#creation du tableau des notes
tableau_note = tableau_note(tableau)

with open('Les_resultats.txt','w') as fichier:
    for ele in tableau_note:
        fichier.write('{:<30}'.format(ele[0])+',  '+'{:.2f}'.format(ele[-1])+'\n')
input('votre fichier avec les résultats a été placé dans votre dossier')
        
